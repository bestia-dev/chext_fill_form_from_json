# chext_fill_form_from_json

Chrome extension to fill a form from json.  
It will be eventually published on Google WebStore.  
You can install it also from the local disk.  
In `chrome://extensions` enable Developer mode.  
Then use `Load unpacked`.  

Open the webpage `/example/efrro_form_c.html`  
start the extension  
and copy/paste the data from `/example/efrro_form_c.json`.  

The first use of this Extension is for `https://www.indianfrro.gov.in/frro/FormC`.  

