# chext_fill_form_from_json

Try the `/example/`:  
fill the form in `efrro_form_c.html`  
with the data in `efrro_form_c.json`.  
Just copy/paste.  
